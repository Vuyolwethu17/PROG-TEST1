/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.personarray.question1;
import java.util.Scanner;
/**
 *
 * @author vuyolwethumpongose
 */
public class Question1 {

    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    System.out.println("------------------------------------------------------------");
    System.out.println("GAMING CONSOLE REPORT");
    System.out.println("------------------------------------------------------------");
    
    String[] names = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"}; //Array of destinsntion names
        
        int[][] sales = {
         {1000, 2000, 3000},
         {2000, 3000, 4000},
         {1500, 1100, 1200} //2D array; column 0 = peak, column 1 = off-peak
                
     };
        int mostSales = 0;
        String mostName = "";
        
        System.out.printf("%-15s%-15s%-15s%-15s%n", " ", "PS5", "XBOX", "SWITCH"); // Print report heading

        for (int i = 0; i < names.length; i++) {         //Loop thorugh each destination; calculate difference and check for biggest difference to add "***"
            int most = sales[i][0] + sales[i][1] + sales[i][2];
            
            if (most > mostSales) {
                mostSales = most;
                mostName = names[i];
}
            
            System.out.printf("%-15s%-15d%-15d%-15d%n", names[i], sales[i][0], sales[i][1], sales[i][2]);
        }
        
        System.out.println();
        System.out.println("------------------------------------------------------------");
        System.out.println("CONSOLE SALES TOTAL FOR EACH CITY");
        System.out.println("------------------------------------------------------------");
        
        System.out.println();
        System.out.printf("%-15s%-15s%n", "CITY", "TOTAL SALES"); // Heading for totals table
        
        for (int i = 0; i < names.length; i++) {                  // Loop through each city
            int total = sales[i][0] + sales[i][1] + sales[i][2];   // Add the 3 consoles for this city
            
            System.out.printf("%-15s%-15d%n", names[i], total);    // Print city and its total
}
        System.out.println();
        System.out.println("City with the most sales: " + mostName + " (R" + mostSales + ")"); //Print deatination with greatest difference
    }
}
