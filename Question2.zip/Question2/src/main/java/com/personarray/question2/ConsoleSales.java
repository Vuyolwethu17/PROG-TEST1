/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.personarray.question2;

/**
 *
 * @author vuyolwethumpongose
 */
public abstract class ConsoleSales implements iConsoleSales {
    
    // Abstract class that implements iConsoleSales
    public abstract class ConsoleSales implements iConsoleSales {

    // Private variables
    private String consoleType;
    private String storeName;
    private double salesAmount;

    // Constructor stores the values
    public ConsoleSales(String type, String store, double sales) {
        consoleType = type;
        storeName = store;
        salesAmount = sales;
    }

    // Getters
    public String getConsoleType() { return consoleType; }
    public String getStoreName() { return storeName; }
    public double getSalesAmount() { return salesAmount; }
    }
}