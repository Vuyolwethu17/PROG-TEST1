/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.personarray.question2;

/**
 *
 * @author vuyolwethumpongose
 */
// Interface: methods every console sale must have
public interface iConsoleSales {
    
    String getConsoleType();
    String getStoreName();
    double getSalesAmount();
    
}
