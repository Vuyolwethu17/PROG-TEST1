/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.personarray.question2;

/**
 *
 * @author vuyolwethumpongose
 */
// Subclass that extends ConsoleSales
public class ConsoleSalesReport extends ConsoleSales {

    // Constructor passes values to the superclass
    public ConsoleSalesReport(String type, String store, double sales) {
        super(type, store, sales);
    }

    // Prints the report
    public void printReport() {
        System.out.println("CONSOLE SALES REPORT");
        System.out.println("Console type: " + getConsoleType());
        System.out.println("Store name:   " + getStoreName());
        System.out.println("Total sales:  R" + String.format("%.2f", getSalesAmount()));
    }
}
