/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.personarray.question2;
import java.util.Scanner;
/**
 *
 * @author vuyolwethumpongose
 */
public class RunApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in); 
        
        // User selects a console device
        System.out.println("Select a console device: 1 = PS5, 2 = XBOX, 3 = SWITCH");
        int choice = input.nextInt();
        input.nextLine();
        
        String consoleType;
        if (choice == 1) {
            consoleType = "PS5";
        
        } else if (choice == 2) {
            consoleType = "XBOX";
        } else {
            consoleType = "SWITCH";
        }
        
        // User enters store name and total sales
        System.out.print("Enter the store name: ");
        String storeName = input.nextLine();
        
        System.out.print("Enter the total sales amount: ");
        double salesAmount = input.nextDouble();
        
        // Create the report object and print it
        ConsoleSalesReport report = new ConsoleSalesReport(consoleType, storeName, salesAmount);
        report.printReport();
    }
    
}
