/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.personarray.question2;

/**
 *
 * @author vuyolwethumpongose
 */
public static void main(String[] args) {
    // Start the application by running RunApplication
    RunApplication.main(args);
}